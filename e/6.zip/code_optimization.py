# --- Copy Propagation ---

a = b = 2
# Before Optimization
c = a * b
x = a
d = x * b + 4
print(d)

# After Optimization
d = a * b + 4
print(d)


# --- Common Sub Expression Elimination ---

a = b = c = 3
# Before Optimization
t1 = a * b
t2 = a * b + c
print(t1, t2)

# After Optimization
t1 = a * b
t2 = t1 + c
print(t1, t2)


# --- Dead Code Elimination ---

# Before Optimization
x = 10
y = 20
print(y)

# After Optimization
y = 20
print(y)


# --- Function Inlining ---

# Before Optimization
def sum(a,b):
    return a + b

x = sum(2,3)
print(x)

# After Optimization
x = 2 + 3
print(x)