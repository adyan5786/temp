COPY    START   1000
FIRST   LDA     ALPHA
        ADD     ONE
        SUB     TWO
        STA     BETA
        END     FIRST
ALPHA   WORD    5
ONE     WORD    1
TWO     WORD    2
BETA    RESW    1
