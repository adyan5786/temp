optab = {}
symtab = {}

with open("optab.txt") as f:
    for line in f:
        opcode, code = line.split()
        optab[opcode] = code

with open("symtab.txt") as f:
    for line in f:
        symbol, address = line.split()
        symtab[symbol] = int(address)

with open("intermediate.txt") as inp, open("objectcode.txt", "w") as out:
    for line in inp:
        loc, label, opcode, operand = line.split()
        loc = int(loc)

        if opcode == "START":
            out.write(f"{loc}\tSTART {operand}\n")

        elif opcode == "END":
            out.write("END\n")

        elif opcode in optab:
            addr = symtab[operand]
            out.write(f"{loc}\t{optab[opcode]}{addr:04d}\n")

        elif opcode == "WORD":
            out.write(f"{loc}\t{int(operand):06d}\n")

        else:
            out.write(f"{loc}\t------\n")

print("PASS 2 completed")
