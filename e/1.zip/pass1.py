symtab = {}
intermediate = []

locctr = 0

with open("source.asm") as f:
    for line in f:
        parts = line.split()

        if len(parts) == 3:
            label, opcode, operand = parts
        else:
            label = "**"
            opcode, operand = parts

        if opcode == "START":
            locctr = int(operand)
            intermediate.append((locctr, label, opcode, operand))
            continue

        intermediate.append((locctr, label, opcode, operand))

        if label != "**":
            symtab[label] = locctr

        if opcode == "WORD":
            locctr += 3
        elif opcode == "RESW":
            locctr += 3 * int(operand)
        elif opcode == "RESB":
            locctr += int(operand)
        elif opcode == "END":
            pass   # DO NOT break
        else:
            locctr += 3

with open("intermediate.txt", "w") as f:
    for row in intermediate:
        f.write(f"{row[0]}\t{row[1]}\t{row[2]}\t{row[3]}\n")

with open("symtab.txt", "w") as f:
    for symbol, address in symtab.items():
        f.write(f"{symbol}\t{address}\n")

print("PASS 1 completed successfully")
